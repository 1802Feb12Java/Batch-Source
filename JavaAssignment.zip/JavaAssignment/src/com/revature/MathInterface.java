/*  This is an interface file for the type of calculation, such as addition, subtraction, multiplication, and division
 * 
 *  @author Dominic Nguyen
 */

package com.revature;

public interface MathInterface {

	public void typeOfCalculation(int type);
}

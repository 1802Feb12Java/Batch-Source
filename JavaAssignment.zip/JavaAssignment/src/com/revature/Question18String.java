/*  This is an abstract class file with abstract methods
 * 
 *  @author Dominic Nguyen
 */

package com.revature;

public abstract class Question18String {
	
	public abstract boolean checkUpperCase(String str);
	public abstract String upperCase(String str);
	public abstract int stringToInteger(String str);
}

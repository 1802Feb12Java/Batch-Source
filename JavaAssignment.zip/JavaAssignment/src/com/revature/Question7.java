package com.revature;

public class Question7 {

	// constructor
	public Question7() {
		
	}
	
	
}
